import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    //Synchronized
    public static int count = 0;
    public static Object locker = new Object();
    public static void main(String[] args) {
        /*int limit = 1000;
        IncThread incThread = new IncThread(limit);
        DeckThread deckThread = new DeckThread(limit);
        incThread.start();
        deckThread.start();
        try {
            incThread.join();
            deckThread.join();
        }
        catch (InterruptedException e){
            e.printStackTrace();
            Logger.getLogger(Thread.class.getName()).log(Level.SEVERE, null, e);
        }
        System.out.println("Counter = " + count);
    }*/
        MyResourse count = new MyResourse();
        Thread t1 = new MyThread(count);
        Thread t2 = new MyThread(count);
        t1.start();
        t2.start();
        try {
          t1.join();
          t2.join();
        }
        catch (InterruptedException e){
            e.printStackTrace();
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
        }
        System.out.println("Counter = " + count.getCount());
    }
}
class MyResourse{
      long count = 0;

      public synchronized void add(long value){
          this.count = this.count+value;
      }
      long getCount(){return  this.count;
      }
}
class MyThread extends Thread{
        protected MyResourse count = null;
        public MyThread(MyResourse count){
            this.count = count;
        }

    @Override
    public void run() {
        for(int i = 0; i <= 100; i++){
            synchronized (Main.locker) {
                count.add(i);
            }
    }
}
}

//Synchronized
class IncThread extends Thread{
    int limit;
    public IncThread(int limit){
        this.limit = limit;
    }
    @Override
    public void run() {
        for(int i = 0; i < limit; i++){
            synchronized (Main.locker) {
                Main.count++;
            }
        }
    }
}
class DeckThread extends Thread {
    int limit;
    public DeckThread(int limit) {
        this.limit = limit;
    }
    @Override
    public void run() {
        for (int i = 0; i < limit; i++) {
            synchronized (Main.locker) {
                Main.count--;
            }
        }
    }
}